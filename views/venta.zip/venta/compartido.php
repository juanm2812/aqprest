<div class="modal inmodal" id="modal-sub-pedido" tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static" data-keyboard="true">
    <div class="modal-dialog">
        <div class="modal-content animated bounceInTop">
        <form method="post" enctype="multipart/form-data" action="#">
            <div class="modal-header justify-center mh-e">
                <h5 class="modal-title mt title-subitems animated fadeIn"></h5>
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Cerrar</span></button>
            </div>
            <div class="modal-body scroll_subitems" style="padding: 0px">
                <div class="comment-widgets m-0" id="list-subitems"></div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Volver</button>
            </div>
        </form>
        </div>
    </div>
</div>